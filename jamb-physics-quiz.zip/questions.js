const questions = [
  {
    question: "What is the unit of power?",
    options: ["Joule", "Watt", "Newton", "Volt"],
    answer: "Watt"
  },
  {
    question: "Which instrument is used to measure electric current?",
    options: ["Voltmeter", "Ammeter", "Galvanometer", "Ohmmeter"],
    answer: "Ammeter"
  }
  // Add more questions below this line
];
