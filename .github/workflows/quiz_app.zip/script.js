const startBtn = document.getElementById("start-btn");
const quizScreen = document.getElementById("quiz-screen");
const startScreen = document.getElementById("start-screen");
const resultScreen = document.getElementById("result-screen");
const questionEl = document.getElementById("question");
const optionsEl = document.getElementById("options");
const prevBtn = document.getElementById("prev-btn");
const nextBtn = document.getElementById("next-btn");
const submitBtn = document.getElementById("submit-btn");
const scoreEl = document.getElementById("score");
const restartBtn = document.getElementById("restart-btn");
const timerEl = document.getElementById("time");

let currentQuestionIndex = 0;
let score = 0;
let timer;
let timeLeft = 60;

// Sample general-purpose questions
const questions = [
  {
    question: "What is the capital of France?",
    options: ["Paris", "London", "Berlin", "Madrid"],
    answer: 0
  },
  {
    question: "Which planet is known as the Red Planet?",
    options: ["Earth", "Mars", "Jupiter", "Venus"],
    answer: 1
  },
  {
    question: "Who developed the theory of relativity?",
    options: ["Isaac Newton", "Albert Einstein", "Galileo Galilei", "Nikola Tesla"],
    answer: 1
  }
];

startBtn.addEventListener("click", startQuiz);
nextBtn.addEventListener("click", () => changeQuestion(1));
prevBtn.addEventListener("click", () => changeQuestion(-1));
submitBtn.addEventListener("click", submitQuiz);
restartBtn.addEventListener("click", restartQuiz);

function startQuiz() {
  startScreen.classList.remove("active");
  quizScreen.classList.add("active");
  showQuestion();
  startTimer();
}

function showQuestion() {
  resetState();
  let currentQuestion = questions[currentQuestionIndex];
  questionEl.innerText = currentQuestion.question;
  currentQuestion.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.innerText = option;
    button.addEventListener("click", () => selectAnswer(button, index));
    optionsEl.appendChild(button);
  });
}

function resetState() {
  optionsEl.innerHTML = "";
}

function selectAnswer(button, index) {
  let correct = questions[currentQuestionIndex].answer === index;
  if (correct) {
    button.classList.add("correct");
    score++;
  } else {
    button.classList.add("wrong");
  }
  Array.from(optionsEl.children).forEach(btn => btn.disabled = true);
}

function changeQuestion(direction) {
  currentQuestionIndex += direction;
  if (currentQuestionIndex < 0) currentQuestionIndex = 0;
  if (currentQuestionIndex >= questions.length) currentQuestionIndex = questions.length - 1;
  showQuestion();
}

function submitQuiz() {
  clearInterval(timer);
  quizScreen.classList.remove("active");
  resultScreen.classList.add("active");
  scoreEl.innerText = `${score} / ${questions.length}`;
}

function restartQuiz() {
  score = 0;
  currentQuestionIndex = 0;
  timeLeft = 60;
  resultScreen.classList.remove("active");
  startScreen.classList.add("active");
}

function startTimer() {
  timer = setInterval(() => {
    timeLeft--;
    timerEl.innerText = timeLeft;
    if (timeLeft <= 0) {
      clearInterval(timer);
      submitQuiz();
    }
  }, 1000);
}
